CREATE DATABASE freelancing_app;
use freelancing_app;
CREATE TABLE users (
    name VARCHAR(50) NOT NULL,
     user_email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(200) NOT NULL,        -- hashed password
    role ENUM('client', 'user') DEFAULT 'user',
    points INT DEFAULT 0,
    status VARCHAR(10),                    -- active/inactive/completedadmin
    phone VARCHAR(15) NOT NULL
);
CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(200) NOT NULL,        -- hashed password
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE client (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    company VARCHAR(100),
    address VARCHAR(200),
    project_details TEXT,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE project (
    project_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    budget DECIMAL(10,2),
    assigned_to INT, 
    start_date DATE,
    end_date DATE NOT NULL,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (client_id) REFERENCES client(client_id),
    FOREIGN KEY (assigned_to) REFERENCES user(user_id)
);
CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    assigned_to INT,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    deadline DATE NOT NULL,
    progress VARCHAR(50),                  -- Not started / in progress / done
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (project_id) REFERENCES project(project_id),
    FOREIGN KEY (assigned_to) REFERENCES user(user_id)
);
CREATE TABLE payment (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    project_id INT,
    amount DECIMAL(10,2) NOT NULL,
    payment_type VARCHAR(50) NOT NULL,     -- Received / Paid
    payment_date DATE NOT NULL,
    notes TEXT,

    FOREIGN KEY (client_id) REFERENCES client(client_id),
    FOREIGN KEY (project_id) REFERENCES project(project_id)
);







