package com.app.main;

import java.util.Scanner;
import com.app.dao.*;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        UserDao userDao = new UserDao();
        ClientDao clientDao = new ClientDao();
        ProjectDao projectDao = new ProjectDao();
        TaskDao taskDao = new TaskDao();

        while (true) {
            System.out.println("\n===== TASK MANAGEMENT SYSTEM =====");
            System.out.println("1. Add User");
            System.out.println("2. Add Client");
            System.out.println("3. Create Project");
            System.out.println("4. Add Task");
            System.out.println("5. Exit");

            System.out.print("Enter choice: ");
            int choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    String uname = sc.nextLine();
                    System.out.print("Email: ");
                    String uemail = sc.nextLine();
                    System.out.print("Role: ");
                    String role = sc.nextLine();
                    System.out.print("Phone: ");
                    String phone = sc.nextLine();
                    System.out.print("Password: ");
                    String password = sc.nextLine();
                    userDao.addUser(uname, uemail, role, phone,password);
                    break;

                case 2:
                    System.out.print("Client Name: ");
                    String cname = sc.nextLine();
                    System.out.print("Email: ");
                    String cemail = sc.nextLine();
                    System.out.print("Phone: ");
                    String cphone = sc.nextLine();
                    clientDao.addClient(cname, cemail, cphone);
                    break;

                case 3:
                    System.out.print("Client ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Project Title: ");
                    String title = sc.nextLine();
                    System.out.print("Budget: ");
                    double budget = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("End Date (yyyy-MM-dd): ");
                    String endDate = sc.nextLine();
                    projectDao.addProject(cid, title, budget, endDate);
                    break;

                case 4:
                    System.out.print("Project ID: ");
                    int pid = sc.nextInt();
                    System.out.print("User ID: ");
                    int uid = sc.nextInt();
                    System.out.print("Task Title: ");
                    String ttitle = sc.nextLine(); 
                    System.out.print("Deadline (YYYY-MM-DD): ");
                    String deadline = sc.nextLine();
                    taskDao.addTask(pid, uid, ttitle, deadline);
                    break;

                case 5:
                    System.out.println("Thank You 🙏");
                    System.exit(0);
            }
        }
    }
}
