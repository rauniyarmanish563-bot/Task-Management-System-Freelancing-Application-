package com.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.app.util.DBConnection;

public class UserDao {

    public void addUser(String name, String email, String role, String phone,String password) {
        String sql =
          "INSERT INTO user(name,email,role,phone,password) VALUES (?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, role);
            ps.setString(4, phone);
            ps.setString(5, password);

            ps.executeUpdate();
            System.out.println("✅ User Added Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
