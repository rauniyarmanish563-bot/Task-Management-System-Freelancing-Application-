package com.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.app.util.DBConnection;
import java.sql.Date;

public class ProjectDao {

    public void addProject(int clientId, String title, double budget ,String endDate) {

        String sql =
          "INSERT INTO project(client_id,title,budget,end_date,status) VALUES (?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, clientId);
            ps.setString(2, title);
            ps.setDouble(3, budget);
            ps.setDate(4, Date.valueOf(endDate));
            ps.setString(5, "active");
            ps.executeUpdate();
            System.out.println("✅ Project Created");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
