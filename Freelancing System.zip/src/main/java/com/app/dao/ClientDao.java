package com.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.app.util.DBConnection;

public class ClientDao {

    public void addClient(String name, String email, String phone) {

        String sql =
          "INSERT INTO client(name,email,phone,status) VALUES (?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, "active");

            ps.executeUpdate();
            System.out.println("✅ Client Added");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
