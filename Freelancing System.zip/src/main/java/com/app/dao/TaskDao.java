package com.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.app.util.DBConnection;

public class TaskDao {

    public void addTask(int projectId, int userId, String title,String deadline) {

        String sql =
          "INSERT INTO tasks(project_id,assigned_to,title,deadline) VALUES (?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, projectId);
            ps.setInt(2, userId);
            ps.setString(3, title);
            ps.setString(4, deadline);

            ps.executeUpdate();
            System.out.println("✅ Task Added");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
