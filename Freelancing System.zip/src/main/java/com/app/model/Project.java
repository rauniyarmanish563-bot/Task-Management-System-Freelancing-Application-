package com.app.model;

import java.sql.Date;

public class Project {

    private int projectId;
    private int clientId;
    private String title;
    private String description;
    private double budget;
    private int assignedTo;
    private Date startDate;
    private Date endDate;
    private String status;

    // 1️⃣ Default Constructor
    public Project() {
    }

    // 2️⃣ Parameterized Constructor
    public Project(int clientId, String title, double budget) {
        this.clientId = clientId;
        this.title = title;
        this.budget = budget;
        this.status = "Active";
    }

    // 3️⃣ Getters and Setters
    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getTitle() {
        return title;
    }
 
    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }

    public double getBudget() {
        return budget;
    }
 
    public void setBudget(double budget) {
        this.budget = budget;
    }

    public int getAssignedTo() {
        return assignedTo;
    }
 
    public void setAssignedTo(int assignedTo) {
        this.assignedTo = assignedTo;
    }

    public Date getStartDate() {
        return startDate;
    }
 
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }
 
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
}
