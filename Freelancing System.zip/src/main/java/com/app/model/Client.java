package com.app.model;

public class Client {

    private int clientId;
    private String name;
    private String email;
    private String phone;
    private String company;
    private String address;
    private String projectDetails;
    private String status;

    // 1️⃣ Default Constructor
    public Client() {
    }

    // 2️⃣ Parameterized Constructor
    public Client(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // 3️⃣ Getters and Setters
    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }
 
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }
 
    public void setCompany(String company) {
        this.company = company;
    }

    public String getAddress() {
        return address;
    }
 
    public void setAddress(String address) {
        this.address = address;
    }

    public String getProjectDetails() {
        return projectDetails;
    }
 
    public void setProjectDetails(String projectDetails) {
        this.projectDetails = projectDetails;
    }

    public String getStatus() {
        return status;
    }
 
    public void setStatus(String status) {
        this.status = status;
    }
}
