package com.app.model;

import java.sql.Date;

public class Task {

    private int taskId;
    private int projectId;
    private int assignedTo;
    private String title;
    private String description;
    private Date deadline;
    private String progress;

    // 1️⃣ Default Constructor
    public Task() {
    }

    // 2️⃣ Parameterized Constructor
    public Task(int projectId, int assignedTo, String title) {
        this.projectId = projectId;
        this.assignedTo = assignedTo;
        this.title = title;
        this.progress = "Not Started";
    }

    // 3️⃣ Getters and Setters
    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(int assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getTitle() {
        return title;
    }
 
    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDeadline() {
        return deadline;
    }
 
    public void setDeadline(Date deadline) {
        this.deadline = deadline;
    }

    public String getProgress() {
        return progress;
    }
 
    public void setProgress(String progress) {
        this.progress = progress;
    }
}
